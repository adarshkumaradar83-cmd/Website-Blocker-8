/* ============================================================
   NEXUSGRID — EXECUTIVE ONBOARDING & DONATION PORTAL
   ============================================================ */
NG.onboard = (function(){

  function capabilityCard(icon, title, body){
    return '<div style="padding:13px 14px;background:rgba(2,6,23,.6);border:1px solid var(--line);border-left:2px solid var(--neon)">'
      + '<div class="mono" style="font-size:9px;letter-spacing:.2em;color:var(--neon);text-transform:uppercase;margin-bottom:5px">'+icon+' '+title+'</div>'
      + '<div style="font-size:11.5px;line-height:1.6;color:var(--ink-3)">'+body+'</div>'
      + '</div>';
  }

  function donationBlock(){
    return ''
      + '<div style="padding:16px;background:linear-gradient(140deg,rgba(34,197,94,.1),rgba(2,6,23,.6));border:1px solid rgba(34,197,94,.3)">'
      +   '<div class="mono" style="font-size:9px;letter-spacing:.22em;color:var(--matrix);text-transform:uppercase">◆ Community Support &amp; Infrastructure Donation Portal</div>'
      +   '<p style="margin:9px 0 14px;font-size:12px;line-height:1.7;color:var(--ink-2)">'
      +     'NexusGrid is developed and maintained independently. Contributions fund ongoing framework '
      +     'development, node-engine optimisation, and continued release of new monitoring modules. '
      +     'Any amount is genuinely appreciated.'
      +   '</p>'
      +   '<div class="copyrow" data-copyrow>'
      +     '<span class="copyrow__k">Official UPI ID</span>'
      +     '<span class="copyrow__v" data-copyval>'+NG.UPI_ID+'</span>'
      +     '<button class="btn btn--sm btn--matrix" data-copybtn>Copy UPI ID</button>'
      +   '</div>'
      +   '<div class="mono" style="margin-top:10px;font-size:9px;letter-spacing:.12em;color:var(--ink-4)">'
      +     'Open any UPI application → Send to UPI ID → paste the address above.'
      +   '</div>'
      + '</div>';
  }

  /** Standalone donation portal (topbar button). */
  function donate(){
    NG.ui.modal({
      title:'Support NexusGrid Development',
      kicker:'Community contribution portal',
      narrow:true,
      body: donationBlock()
        + '<div class="prose" style="margin-top:16px">'
        + '<h4>Where contributions go</h4>'
        + '<ul><li>Node engine performance work &amp; memory profiling</li>'
        + '<li>New monitoring &amp; auditing modules</li>'
        + '<li>Long-term maintenance and compatibility testing</li></ul>'
        + '<p style="margin-top:12px">Prefer to help without contributing financially? Report faults with a diagnostic export to '
        + '<a href="mailto:'+NG.SUPPORT_EMAIL+'">'+NG.SUPPORT_EMAIL+'</a> — quality reports are just as valuable.</p>'
        + '</div>',
      foot:'<button class="btn btn--ghost" data-x>Close</button>'
    });
  }

  /** Full executive briefing shown on login. */
  function welcome(user, opts){
    opts = opts || {};
    const name = (user && user.name) || 'Operator';

    NG.ui.modal({
      title:'Welcome to NexusGrid Systems',
      kicker:'Executive briefing · Build 4.2.0 · Serverless Edition',
      wide:true,
      body:''
        + '<div style="margin-bottom:18px">'
        +   '<div class="display" style="font-size:17px;color:#fff;letter-spacing:.06em">Operator '+NG.ui.esc(name)+', the grid is yours.</div>'
        +   '<p style="margin-top:9px;font-size:13px;line-height:1.75;color:var(--ink-2)">'
        +     '<strong style="color:var(--ink)">NexusGrid Systems</strong> is a next-generation concurrent multi-tab '
        +     'control and performance monitoring terminal. Dispatch large sets of target URLs into isolated '
        +     'execution nodes, drive them from a unified command layer, and audit responsive behaviour, network '
        +     'degradation, and lifecycle faults side by side — with zero backend infrastructure. Every byte of '
        +     'state lives in your own browser.'
        +   '</p>'
        + '</div>'

        + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(215px,1fr));gap:9px;margin-bottom:18px">'
        +   capabilityCard('01','Multi-Node Dispatcher','Paste or drop any number of URLs. Each becomes a sandboxed node in a high-density grid, scalable to 100 concurrent contexts.')
        +   capabilityCard('02','Unified Global Control','Synchronised hard-refresh with cache-bypass tokens, plus mass pause, resume, and terminate across the entire grid.')
        +   capabilityCard('03','Viewport Emulator','Flip any node between Desktop, Tablet (768px), and Mobile (375px) for instant responsive auditing.')
        +   capabilityCard('04','Network Throttling','Simulate Fast 4G, Slow 3G, or a hard Offline state per node to observe degradation behaviour.')
        +   capabilityCard('05','Diagnostic Drawer','Every load, block, and fault is captured in a unified log — archived to IndexedDB, never crashing the UI.')
        +   capabilityCard('06','Session Persistence','Workspace layout and targets auto-save to LocalStorage, with full JSON export and import.')
        + '</div>'

        + '<div style="padding:15px 16px;background:linear-gradient(140deg,rgba(59,130,246,.13),rgba(2,6,23,.5));border:1px solid var(--line-2);margin-bottom:16px">'
        +   '<div class="mono" style="font-size:9px;letter-spacing:.22em;color:var(--neon);text-transform:uppercase">◆ Special Acknowledgments</div>'
        +   '<div style="margin-top:11px;display:flex;align-items:center;gap:13px;flex-wrap:wrap">'
        +     '<div style="flex:none;width:44px;height:44px;display:grid;place-items:center;background:linear-gradient(135deg,var(--neon),#1e3a8a);clip-path:polygon(50% 0,100% 25%,100% 75%,50% 100%,0 75%,0 25%);font-family:var(--f-display);font-size:13px;color:#fff">AK</div>'
        +     '<div style="min-width:200px;flex:1">'
        +       '<div class="mono" style="font-size:9px;letter-spacing:.16em;color:var(--ink-3);text-transform:uppercase">Core Architecture &amp; Conceptual Design</div>'
        +       '<div class="display" style="font-size:15px;color:#fff;margin-top:4px;letter-spacing:.08em">ADARSH KUMAR</div>'
        +       '<div style="font-size:11.5px;color:var(--ink-3);margin-top:5px">Special thanks for the conceptual design and core architecture of the NexusGrid execution framework.</div>'
        +     '</div>'
        +   '</div>'
        + '</div>'

        + donationBlock()

        + '<div class="hint" style="margin-top:16px">'
        +   '<span style="color:var(--amber)">▸</span>'
        +   '<span><strong style="color:var(--ink)">Operational note:</strong> many production sites send anti-framing headers '
        +   '(<code>X-Frame-Options</code>) and will legitimately refuse to render inside a node. NexusGrid detects and logs '
        +   'these blocks cleanly rather than failing silently.</span>'
        + '</div>',

      foot:''
        + '<label class="check" style="margin-right:auto;align-self:center">'
        +   '<input type="checkbox" id="obSkip"><span class="check__box"></span>'
        +   '<span style="font-size:11px">Don\'t show this briefing again</span>'
        + '</label>'
        + '<button class="btn btn--ghost" data-open="support">Support Center</button>'
        + '<button class="btn btn--solid" data-x>Enter Grid Terminal</button>',

      onMount(w, close){
        const skip = w.querySelector('#obSkip');
        skip.checked = !!NG.store.get(NG.K.SEEN, false);
        skip.addEventListener('change', ()=>{
          NG.store.set(NG.K.SEEN, skip.checked);
          NG.ui.toast(skip.checked ? 'Briefing suppressed for future sessions.' : 'Briefing re-enabled.', 'info');
        });
        if(opts.onClose) w.addEventListener('ng:closed', opts.onClose);
      }
    });

    NG.diag.info('ONBOARD','Executive briefing presented to '+name);
  }

  return { welcome, donate };
})();
