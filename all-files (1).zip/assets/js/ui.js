/* ============================================================
   NEXUSGRID — UI KIT
   Toasts, modal stack, clipboard, download, URL utilities
   ============================================================ */
NG.ui = (function(){
  const layer  = () => document.getElementById('modalLayer');
  const toasts = () => document.getElementById('toastRail');
  let openStack = [];

  /* ---------------- toast ---------------- */
  function toast(msg, kind, title){
    const rail = toasts();
    if(!rail) return;
    const el = document.createElement('div');
    el.className = 'toast toast--' + (kind||'info');
    el.innerHTML = '<div><span class="toast__t">'
      + esc(title || ({ok:'Confirmed',err:'Fault',warn:'Advisory'}[kind] || 'Notice'))
      + '</span>' + esc(msg) + '</div>';
    rail.appendChild(el);
    const kill = ()=>{
      el.classList.add('is-out');
      setTimeout(()=>el.remove(), 320);
    };
    const t = setTimeout(kill, 4200);
    el.addEventListener('click', ()=>{ clearTimeout(t); kill(); });
  }

  function esc(s){
    return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  }

  /* ---------------- modal ---------------- */
  /**
   * @param {object} o {title, kicker, body, foot, wide, narrow, onMount}
   * @returns {function} close
   */
  function modal(o){
    const host = layer();
    const wrap = document.createElement('div');
    wrap.className = 'modal';
    wrap.innerHTML =
      '<div class="sheet ticks '+(o.wide?'sheet--wide':'')+(o.narrow?'sheet--narrow':'')+'" role="dialog" aria-modal="true">'
      +  '<div class="sheet__head"><div>'
      +    '<div class="sheet__title">'+esc(o.title||'')+'</div>'
      +    (o.kicker?'<div class="eyebrow sheet__kicker">'+esc(o.kicker)+'</div>':'')
      +  '</div><button class="sheet__x" data-x aria-label="Close">✕</button></div>'
      +  '<div class="sheet__body">'+(o.body||'')+'</div>'
      +  (o.foot?'<div class="sheet__foot">'+o.foot+'</div>':'')
      + '</div>';
    host.appendChild(wrap);

    function close(){
      wrap.classList.add('is-out');
      setTimeout(()=>wrap.remove(), 270);
      openStack = openStack.filter(f=>f!==close);
      if(!openStack.length) document.body.style.overflow='';
    }
    openStack.push(close);
    document.body.style.overflow = 'hidden';

    wrap.querySelectorAll('[data-x]').forEach(b=>b.addEventListener('click', close));
    wrap.addEventListener('mousedown', e=>{ if(e.target===wrap) close(); });

    if(o.onMount) o.onMount(wrap, close);
    const first = wrap.querySelector('input,textarea,select,button:not([data-x])');
    if(first) setTimeout(()=>first.focus(), 90);
    return close;
  }

  document.addEventListener('keydown', e=>{
    if(e.key==='Escape' && openStack.length) openStack[openStack.length-1]();
  });

  function confirmBox(o){
    return modal({
      title: o.title||'Confirm action',
      kicker: o.kicker||'Destructive operation',
      narrow:true,
      body: '<div class="prose">'+(o.body||'')+'</div>',
      foot: '<button class="btn btn--ghost" data-x>Abort</button>'
          + '<button class="btn '+(o.danger?'btn--alert':'btn--solid')+'" data-go>'+esc(o.okText||'Confirm')+'</button>',
      onMount(w, close){
        w.querySelector('[data-go]').addEventListener('click', ()=>{ close(); o.onOk && o.onOk(); });
      }
    });
  }

  /* ---------------- clipboard ---------------- */
  function copy(text, rowEl, label){
    const done = ok=>{
      if(ok){
        if(rowEl){
          rowEl.classList.add('is-copied');
          setTimeout(()=>rowEl.classList.remove('is-copied'), 900);
        }
        toast((label||'Value')+' copied to clipboard.', 'ok');
      }else{
        toast('Clipboard blocked by browser. Select the value manually.', 'warn');
      }
    };
    if(navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(text).then(()=>done(true)).catch(()=>done(legacy(text)));
    }else{
      done(legacy(text));
    }
  }

  function legacy(text){
    try{
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText='position:fixed;top:-2000px;opacity:0';
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand('copy');
      ta.remove();
      return ok;
    }catch(e){ return false; }
  }

  /* ---------------- download ---------------- */
  function download(name, content, mime){
    try{
      const blob = new Blob([content], {type: mime||'application/json'});
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href = url; a.download = name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(()=>URL.revokeObjectURL(url), 1200);
      return true;
    }catch(e){
      NG.diag.err('EXPORT','Download failed: '+e.message);
      return false;
    }
  }

  /* ---------------- URL helpers ---------------- */
  function normalize(raw){
    let s = String(raw||'').trim().replace(/[,;]+$/,'');
    if(!s) return null;
    if(!/^https?:\/\//i.test(s)){
      if(/^(localhost|127\.0\.0\.1)(:\d+)?/i.test(s)) s = 'http://' + s;
      else if(/^[\w-]+(\.[\w-]+)+/.test(s)) s = 'https://' + s;
      else return null;
    }
    try{
      const u = new URL(s);
      if(u.protocol!=='http:' && u.protocol!=='https:') return null;
      return u.href;
    }catch(e){ return null; }
  }

  function host(url){
    try{ return new URL(url).hostname.replace(/^www\./,''); }
    catch(e){ return url; }
  }

  function pathOf(url){
    try{
      const u = new URL(url);
      const p = u.pathname + u.search;
      return p === '/' ? '' : p;
    }catch(e){ return ''; }
  }

  /** Append/refresh a cache-bust token. */
  function bust(url){
    try{
      const u = new URL(url);
      u.searchParams.set('t', Date.now().toString(36));
      return u.href;
    }catch(e){
      return url + (url.indexOf('?')>-1?'&':'?') + 't=' + Date.now().toString(36);
    }
  }

  /** Strip our own cache-bust token for clean display/export. */
  function clean(url){
    try{
      const u = new URL(url);
      u.searchParams.delete('t');
      return u.href.replace(/\?$/,'');
    }catch(e){ return url; }
  }

  function ago(ts){
    if(!ts) return '—';
    const s = Math.max(0, Math.round((Date.now()-ts)/1000));
    if(s<60) return s+'s';
    if(s<3600) return Math.floor(s/60)+'m';
    if(s<86400) return Math.floor(s/3600)+'h';
    return Math.floor(s/86400)+'d';
  }

  return { toast, modal, confirmBox, copy, download, normalize, host, pathOf, bust, clean, ago, esc };
})();
