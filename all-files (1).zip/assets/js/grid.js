/* ============================================================
   NEXUSGRID — CORE EXECUTION ENGINE
   Node lifecycle, iframe dispatch, viewport/throttle emulation
   ============================================================ */
NG.grid = (function(){
  const MAX_NODES = 100;
  const $ = id => document.getElementById(id);

  let ws = null;               // live workspace config
  let gridEl = null;
  let saveTimer = null;
  let cronTimer = null;
  let cronDue = 0;

  const THROTTLE = {
    fast   : { label:'FAST 4G',  delay:0,    kbps:null, offline:false },
    slow3g : { label:'SLOW 3G',  delay:2200, kbps:400,  offline:false },
    slow2g : { label:'SLOW 2G',  delay:5000, kbps:100,  offline:false },
    offline: { label:'OFFLINE',  delay:0,    kbps:0,    offline:true  }
  };
  const VIEWPORTS = { desktop:'DESKTOP', tablet:'TABLET 768', mobile:'MOBILE 375' };

  const ICON = {
    reload : '<svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/></svg>',
    max    : '<svg viewBox="0 0 24 24"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3m13-5v3a2 2 0 0 0-2 2h-3"/></svg>',
    min    : '<svg viewBox="0 0 24 24"><path d="M4 14h6v6M20 10h-6V4M14 10l7-7M3 21l7-7"/></svg>',
    pause  : '<svg viewBox="0 0 24 24"><path d="M10 4v16M14 4v16"/></svg>',
    play   : '<svg viewBox="0 0 24 24"><path d="M6 3l14 9-14 9V3z"/></svg>',
    kill   : '<svg viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg>',
    open   : '<svg viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6M10 14 21 3"/></svg>'
  };

  /* ============================================================
     STATE
     ============================================================ */
  function mkNode(url){
    return {
      id      : NG.uid('n'),
      url     : NG.ui.clean(url),
      vp      : 'desktop',
      net     : 'fast',
      paused  : false,
      state   : 'idle',        // idle | loading | live | error | offline
      loads   : 0,
      lastLoad: 0,
      note    : ''
    };
  }

  function find(id){ return ws.nodes.find(n=>n.id===id); }

  function persist(){
    clearTimeout(saveTimer);
    saveTimer = setTimeout(()=>{
      NG.workspace.save(ws);
      const el = $('tmSaved');
      if(el) el.innerHTML = 'SESSION <b>SAVED ' + new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) + '</b>';
    }, 320);
  }

  /* ============================================================
     RENDER
     ============================================================ */
  function nodeHTML(n, idx){
    const t = THROTTLE[n.net] || THROTTLE.fast;
    return ''
    + '<div class="node__head">'
    +   '<span class="node__id">N'+String(idx+1).padStart(2,'0')+'</span>'
    +   '<span class="node__host" title="'+NG.ui.esc(n.url)+'">'+NG.ui.esc(NG.ui.host(n.url))
    +     '<span>'+NG.ui.esc(NG.ui.pathOf(n.url))+'</span></span>'
    +   '<span class="node__ctl">'
    +     '<button class="ico" data-act="reload" title="Reload node">'+ICON.reload+'</button>'
    +     '<button class="ico" data-act="pause" data-on="'+(n.paused?1:0)+'" title="Pause / resume">'+(n.paused?ICON.play:ICON.pause)+'</button>'
    +     '<button class="ico" data-act="max" title="Expand fullscreen">'+ICON.max+'</button>'
    +     '<button class="ico" data-act="open" title="Open in real browser tab">'+ICON.open+'</button>'
    +     '<button class="ico ico--alert" data-act="kill" title="Terminate node">'+ICON.kill+'</button>'
    +   '</span>'
    + '</div>'

    + '<div class="node__meta">'
    +   '<select class="ngsel" data-act="vp" aria-label="Viewport">'
    +     Object.keys(VIEWPORTS).map(k=>'<option value="'+k+'"'+(n.vp===k?' selected':'')+'>'+VIEWPORTS[k]+'</option>').join('')
    +   '</select>'
    +   '<select class="ngsel" data-act="net" aria-label="Network profile">'
    +     Object.keys(THROTTLE).map(k=>'<option value="'+k+'"'+(n.net===k?' selected':'')+'>'+THROTTLE[k].label+'</option>').join('')
    +   '</select>'
    +   '<span class="sp"></span>'
    +   '<span>LOADS <b>'+n.loads+'</b></span>'
    +   '<span>AGE <b data-age>'+NG.ui.ago(n.lastLoad)+'</b></span>'
    + '</div>'

    + '<div class="node__view" data-view></div>';
  }

  function paint(){
    if(!gridEl) return;

    if(!ws.nodes.length){
      gridEl.innerHTML = ''
        + '<div class="void">'
        +   '<div class="void__g"><i></i></div>'
        +   '<h3>NO ACTIVE EXECUTION NODES</h3>'
        +   '<p>Dispatch one or more target URLs from the panel above to populate the grid. '
        +      'Paste a list, drop a text selection, or pick a quick target to begin monitoring.</p>'
        +   '<div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center">'
        +     '<button class="btn btn--solid btn--sm" data-void="focus">Focus Dispatcher</button>'
        +     '<button class="btn btn--ghost btn--sm" data-void="sample">Load Sample Set</button>'
        +   '</div>'
        + '</div>';
      telemetry();
      return;
    }

    // Reconcile: keep existing DOM/iframes, add/remove as needed.
    const seen = {};
    ws.nodes.forEach((n,i)=>{
      seen[n.id] = 1;
      let card = gridEl.querySelector('[data-id="'+n.id+'"]');
      if(!card){
        card = document.createElement('article');
        card.className = 'node ticks';
        card.dataset.id = n.id;
        card.style.animationDelay = Math.min(i*40, 600)+'ms';
        card.innerHTML = nodeHTML(n, i);
        gridEl.appendChild(card);
        wireNode(card, n);
        boot(n, card);
      }
      card.dataset.state  = n.state;
      card.dataset.vp     = n.vp;
      card.dataset.paused = n.paused ? '1' : '0';
      card.style.setProperty('--vh', ws.height+'px');
      // keep ordinal label in sync after removals
      const idEl = card.querySelector('.node__id');
      if(idEl) idEl.textContent = 'N'+String(i+1).padStart(2,'0');
    });

    Array.from(gridEl.children).forEach(c=>{
      if(c.dataset.id && !seen[c.dataset.id]) c.remove();
      if(c.classList.contains('void')) c.remove();
    });

    telemetry();
  }

  /* ============================================================
     IFRAME LIFECYCLE
     ============================================================ */
  function mask(kind, title, body){
    return '<div class="node__mask '+(kind?'node__mask--'+kind:'')+'">'
      + '<h5>'+title+'</h5><p>'+body+'</p></div>';
  }

  function boot(n, card){
    const view = card.querySelector('[data-view]');
    if(!view) return;
    const t = THROTTLE[n.net] || THROTTLE.fast;

    // OFFLINE profile: never dispatch a request.
    if(t.offline){
      n.state = 'offline';
      view.innerHTML = mask('', 'NODE OFFLINE',
        'Network profile is set to <b>OFFLINE</b>. No request dispatched. Switch the profile to resume traffic.');
      card.dataset.state = 'offline';
      NG.diag.warn('NODE '+NG.ui.host(n.url), 'Offline profile active — request suppressed.');
      telemetry();
      return;
    }

    if(n.paused){
      n.state = 'idle';
      view.innerHTML = mask('idle','NODE SUSPENDED','Execution paused by operator. Resume to restore the live view.');
      card.dataset.state = 'idle';
      telemetry();
      return;
    }

    n.state = 'loading';
    card.dataset.state = 'loading';
    view.innerHTML = '<div class="node__load"><i></i>ESTABLISHING LINK…</div>';

    const launch = ()=>{
      // Node may have been terminated while throttle delay elapsed.
      if(!find(n.id) || !card.isConnected) return;

      const fr = document.createElement('iframe');
      fr.setAttribute('referrerpolicy','no-referrer');
      fr.setAttribute('loading','lazy');
      fr.setAttribute('sandbox','allow-scripts allow-same-origin allow-forms allow-popups allow-pointer-lock');
      fr.setAttribute('title','Node '+NG.ui.host(n.url));
      let settled = false;

      // Cross-origin frames cannot be inspected; a load event is our only
      // positive signal. Absence of it within the window implies a block.
      const guard = setTimeout(()=>{
        if(settled) return;
        settled = true;
        n.state = 'error';
        card.dataset.state = 'error';
        view.insertAdjacentHTML('beforeend', mask('',
          'CONNECTION BLOCKED',
          'No load signal received. The target likely refuses embedding via '
          + '<code>X-Frame-Options</code> or <code>frame-ancestors</code>.<br><br><code>'
          + NG.ui.esc(NG.ui.host(n.url)) + '</code>'));
        NG.diag.err('NODE '+NG.ui.host(n.url), 'Frame blocked or unreachable — no load event within timeout.');
        telemetry();
      }, 12000 + t.delay);

      fr.addEventListener('load', ()=>{
        if(settled) return;
        settled = true;
        clearTimeout(guard);
        n.state = 'live';
        n.loads++;
        n.lastLoad = Date.now();
        card.dataset.state = 'live';
        const ld = view.querySelector('.node__load');
        if(ld) ld.remove();
        const mk = view.querySelector('.node__mask');
        if(mk) mk.remove();
        refreshMeta(card, n);
        NG.diag.ok('NODE '+NG.ui.host(n.url), 'Frame load complete'
          + (t.delay ? ' (throttled '+t.label+')' : '') + '.');
        telemetry();
        persist();
      });

      fr.addEventListener('error', ()=>{
        if(settled) return;
        settled = true;
        clearTimeout(guard);
        n.state = 'error';
        card.dataset.state = 'error';
        view.innerHTML = mask('','TRANSPORT FAULT','The browser reported a load error for this target.');
        NG.diag.err('NODE '+NG.ui.host(n.url),'Transport error during frame load.');
        telemetry();
      });

      fr.src = NG.ui.bust(n.url);
      view.appendChild(fr);
    };

    if(t.delay){
      NG.diag.info('NODE '+NG.ui.host(n.url), 'Throttle profile '+t.label+' — delaying dispatch '+t.delay+'ms.');
      setTimeout(launch, t.delay);
    }else{
      launch();
    }
  }

  function refreshMeta(card, n){
    const meta = card.querySelector('.node__meta');
    if(!meta) return;
    const b = meta.querySelectorAll('b');
    if(b[0]) b[0].textContent = n.loads;
    if(b[1]) b[1].textContent = NG.ui.ago(n.lastLoad);
  }

  /* ============================================================
     NODE INTERACTIONS
     ============================================================ */
  function wireNode(card, n){
    card.addEventListener('click', e=>{
      const b = e.target.closest('[data-act]');
      if(!b || b.tagName === 'SELECT') return;
      const act = b.dataset.act;
      const node = find(card.dataset.id);
      if(!node) return;

      if(act === 'reload'){
        NG.diag.info('NODE '+NG.ui.host(node.url),'Manual reload requested.');
        boot(node, card);
      }
      if(act === 'pause'){
        node.paused = !node.paused;
        b.dataset.on = node.paused ? '1' : '0';
        b.innerHTML = node.paused ? ICON.play : ICON.pause;
        card.dataset.paused = node.paused ? '1' : '0';
        NG.diag.info('NODE '+NG.ui.host(node.url), node.paused ? 'Node suspended.' : 'Node resumed.');
        boot(node, card);
        persist();
      }
      if(act === 'max'){
        const on = card.classList.toggle('is-max');
        b.innerHTML = on ? ICON.min : ICON.max;
        b.title = on ? 'Restore size' : 'Expand fullscreen';
        document.body.style.overflow = on ? 'hidden' : '';
      }
      if(act === 'open'){
        window.open(node.url, '_blank', 'noopener');
        NG.diag.info('NODE '+NG.ui.host(node.url),'Opened in external browser tab.');
      }
      if(act === 'kill'){
        remove(node.id);
      }
    });

    card.addEventListener('change', e=>{
      const s = e.target.closest('select[data-act]');
      if(!s) return;
      const node = find(card.dataset.id);
      if(!node) return;
      if(s.dataset.act === 'vp'){
        node.vp = s.value;
        card.dataset.vp = node.vp;
        NG.diag.info('NODE '+NG.ui.host(node.url),'Viewport → '+VIEWPORTS[node.vp]+'.');
        persist();
      }
      if(s.dataset.act === 'net'){
        node.net = s.value;
        NG.diag.info('NODE '+NG.ui.host(node.url),'Network profile → '+THROTTLE[node.net].label+'.');
        boot(node, card);
        persist();
      }
    });

    card.addEventListener('mouseenter', ()=>card.classList.add('is-focus'));
    card.addEventListener('mouseleave', ()=>card.classList.remove('is-focus'));
  }

  /* ============================================================
     PUBLIC OPERATIONS
     ============================================================ */
  function parse(text){
    const raw = String(text||'').split(/[\s,;]+/).filter(Boolean);
    const good = [], bad = [];
    raw.forEach(r=>{
      const u = NG.ui.normalize(r);
      if(u) good.push(u); else bad.push(r);
    });
    return { good, bad };
  }

  function add(list, silent){
    const room = MAX_NODES - ws.nodes.length;
    if(room <= 0){
      NG.ui.toast('Grid saturated at '+MAX_NODES+' nodes. Terminate some to continue.','warn');
      NG.diag.warn('GRID','Dispatch rejected — node ceiling reached.');
      return 0;
    }
    let dupes = 0;
    const existing = ws.nodes.map(n=>NG.ui.clean(n.url));
    const queue = [];
    list.forEach(u=>{
      const c = NG.ui.clean(u);
      if(existing.indexOf(c) > -1){ dupes++; return; }
      existing.push(c);
      queue.push(c);
    });

    const take = queue.slice(0, room);
    take.forEach(u=>ws.nodes.push(mkNode(u)));
    paint();
    persist();

    if(take.length) NG.diag.ok('GRID','Dispatched '+take.length+' node'+(take.length>1?'s':'')+'.');
    if(!silent){
      if(take.length) NG.ui.toast('Deployed '+take.length+' node'+(take.length>1?'s':'')+'.','ok');
      if(dupes) NG.ui.toast(dupes+' duplicate target'+(dupes>1?'s':'')+' skipped.','warn');
      if(queue.length > room) NG.ui.toast((queue.length-room)+' target(s) exceeded the 100-node ceiling.','warn');
    }
    return take.length;
  }

  function remove(id){
    const n = find(id);
    if(!n) return;
    ws.nodes = ws.nodes.filter(x=>x.id!==id);
    const card = gridEl.querySelector('[data-id="'+id+'"]');
    if(card){
      card.classList.remove('is-max');
      document.body.style.overflow = '';
      card.style.transition = 'opacity .25s, transform .25s';
      card.style.opacity = '0';
      card.style.transform = 'scale(.96)';
      setTimeout(()=>{ card.remove(); paint(); }, 240);
    }
    NG.diag.warn('NODE '+NG.ui.host(n.url),'Node terminated by operator.');
    persist();
  }

  function refreshAll(){
    if(!ws.nodes.length){ NG.ui.toast('No nodes to refresh.','warn'); return; }
    NG.diag.info('GRID','Global synchronized hard-refresh initiated ('+ws.nodes.length+' nodes, cache-bypass).');
    ws.nodes.forEach((n,i)=>{
      const card = gridEl.querySelector('[data-id="'+n.id+'"]');
      if(!card) return;
      setTimeout(()=>{ if(find(n.id)) boot(n, card); }, i*70);  // stagger to avoid thrash
    });
    stamp();
    NG.ui.toast('Hard-refresh dispatched across '+ws.nodes.length+' node(s).','ok');
  }

  function pauseAll(force){
    if(!ws.nodes.length){ NG.ui.toast('No nodes in grid.','warn'); return; }
    const target = typeof force === 'boolean' ? force : !ws.paused;
    ws.paused = target;
    ws.nodes.forEach(n=>{
      n.paused = target;
      const card = gridEl.querySelector('[data-id="'+n.id+'"]');
      if(card){
        const b = card.querySelector('[data-act="pause"]');
        if(b){ b.dataset.on = target?'1':'0'; b.innerHTML = target?ICON.play:ICON.pause; }
        card.dataset.paused = target?'1':'0';
        boot(n, card);
      }
    });
    $('btnPauseAll').textContent = target ? 'Resume All' : 'Pause All';
    NG.diag.info('GRID', target ? 'All nodes suspended.' : 'All nodes resumed.');
    NG.ui.toast(target ? 'Grid suspended.' : 'Grid resumed.','ok');
    persist();
  }

  function clearAll(){
    if(!ws.nodes.length){ NG.ui.toast('Grid is already empty.','warn'); return; }
    NG.ui.confirmBox({
      title:'Terminate all nodes?',
      danger:true, okText:'Terminate Grid',
      body:'<p>This will destroy <strong>'+ws.nodes.length+'</strong> active execution node(s) and clear the saved '
         + 'workspace layout. Diagnostic history is retained.</p><p>Export your workspace first if you want to restore it later.</p>',
      onOk(){
        const c = ws.nodes.length;
        ws.nodes = [];
        ws.paused = false;
        $('btnPauseAll').textContent = 'Pause All';
        paint();
        persist();
        NG.diag.warn('GRID','All nodes terminated ('+c+').');
        NG.ui.toast('Grid cleared — '+c+' node(s) terminated.','ok');
      }
    });
  }

  function setCols(c){
    ws.cols = Math.max(1, Math.min(6, parseInt(c,10)||3));
    gridEl.style.setProperty('--cols', ws.cols);
    document.querySelectorAll('#colSeg button').forEach(b=>{
      b.setAttribute('aria-pressed', String(+b.dataset.cols === ws.cols));
    });
    persist();
  }

  function setHeight(px){
    ws.height = Math.max(180, Math.min(800, parseInt(px,10)||300));
    $('heightVal').textContent = ws.height + ' px';
    $('heightRange').value = ws.height;
    gridEl.querySelectorAll('.node').forEach(c=>c.style.setProperty('--vh', ws.height+'px'));
    persist();
  }

  /* ---------------- cron ---------------- */
  function setCron(sec){
    ws.cron = parseInt(sec,10) || 0;
    clearInterval(cronTimer);
    cronTimer = null;
    $('cronLed').dataset.on = ws.cron ? '1' : '0';
    $('cronSelect').value = String(ws.cron);

    if(ws.cron){
      cronDue = Date.now() + ws.cron*1000;
      cronTimer = setInterval(()=>{
        if(Date.now() >= cronDue){
          cronDue = Date.now() + ws.cron*1000;
          if(ws.nodes.length){
            NG.diag.info('CRON','Scheduled auto-refresh cycle triggered.');
            ws.nodes.forEach((n,i)=>{
              const card = gridEl.querySelector('[data-id="'+n.id+'"]');
              if(card && !n.paused) setTimeout(()=>{ if(find(n.id)) boot(n, card); }, i*70);
            });
            stamp();
          }
        }
        cronTick();
      }, 1000);
      NG.diag.ok('CRON','Polling enabled at '+ws.cron+'s interval.');
      NG.ui.toast('Auto-refresh armed — every '+ws.cron+'s.','ok');
    }else{
      $('cronNext').textContent = 'Polling inactive';
      $('tmCron').innerHTML = '<span class="dot"></span>CRON OFF';
      NG.diag.info('CRON','Polling disabled.');
    }
    cronTick();
    persist();
  }

  function cronTick(){
    if(!ws.cron){ return; }
    const left = Math.max(0, Math.round((cronDue - Date.now())/1000));
    $('cronNext').textContent = 'Next cycle in ' + left + 's';
    $('tmCron').innerHTML = '<span class="dot dot--live"></span>CRON <b>'+ws.cron+'s</b> · T-'+left;
  }

  /* ---------------- telemetry ---------------- */
  function telemetry(){
    const live = ws.nodes.filter(n=>n.state==='live').length;
    const errs = ws.nodes.filter(n=>n.state==='error').length;
    $('tmNodes').textContent = ws.nodes.length;
    $('tmLive').textContent  = live;
    $('tmErr').textContent   = errs;
  }

  function stamp(){
    const el = $('gridStamp');
    if(el) el.innerHTML = '<span class="dot dot--live"></span>LAST SYNC ' + new Date().toLocaleTimeString();
  }

  /* age ticker */
  setInterval(()=>{
    if(!ws || !gridEl) return;
    ws.nodes.forEach(n=>{
      const card = gridEl.querySelector('[data-id="'+n.id+'"]');
      if(card) refreshMeta(card, n);
    });
  }, 15000);

  /* ============================================================
     EXPORT / IMPORT
     ============================================================ */
  function exportWS(){
    const payload = {
      format : 'nexusgrid.workspace',
      version: 1,
      exported: new Date().toISOString(),
      operator: (NG.session.current()||{}).email || 'unknown',
      config : { cols:ws.cols, height:ws.height, cron:ws.cron },
      nodes  : ws.nodes.map(n=>({ url:NG.ui.clean(n.url), vp:n.vp, net:n.net, paused:n.paused }))
    };
    const name = 'nexusgrid-workspace-' + new Date().toISOString().slice(0,19).replace(/[:T]/g,'-') + '.json';
    if(NG.ui.download(name, JSON.stringify(payload,null,2))){
      NG.diag.ok('EXPORT','Workspace exported — '+payload.nodes.length+' node(s) → '+name);
      NG.ui.toast('Workspace exported ('+payload.nodes.length+' nodes).','ok');
    }
  }

  function importWS(text, filename){
    let data;
    try{ data = JSON.parse(text); }
    catch(e){
      NG.diag.err('IMPORT','Malformed JSON in '+(filename||'file')+': '+e.message);
      NG.ui.toast('Import failed — file is not valid JSON.','err');
      return;
    }
    // Accept our envelope, or a bare array of URLs/objects.
    let nodes = null;
    if(Array.isArray(data)) nodes = data;
    else if(data && Array.isArray(data.nodes)) nodes = data.nodes;

    if(!nodes){
      NG.diag.err('IMPORT','Unrecognised workspace structure in '+(filename||'file')+'.');
      NG.ui.toast('Import failed — no node list found.','err');
      return;
    }

    const cfg = data.config || {};
    const urls = [];
    const restored = [];
    nodes.forEach(item=>{
      const raw = typeof item === 'string' ? item : (item && item.url);
      const u = NG.ui.normalize(raw);
      if(!u) return;
      urls.push(u);
      restored.push({
        url : NG.ui.clean(u),
        vp  : (item && VIEWPORTS[item.vp]) ? item.vp : 'desktop',
        net  : (item && THROTTLE[item.net]) ? item.net : 'fast',
        paused: !!(item && item.paused)
      });
    });

    if(!restored.length){
      NG.diag.err('IMPORT','No valid URLs recovered from '+(filename||'file')+'.');
      NG.ui.toast('Import failed — no usable URLs.','err');
      return;
    }

    NG.ui.confirmBox({
      title:'Restore workspace?',
      okText:'Replace Grid',
      kicker:'Import · '+restored.length+' node(s)',
      body:'<p>Found <strong>'+restored.length+'</strong> valid node definition(s)'
        + (filename?' in <code>'+NG.ui.esc(filename)+'</code>':'') + '.</p>'
        + '<p>This replaces your current grid of <strong>'+ws.nodes.length+'</strong> node(s).</p>',
      onOk(){
        ws.nodes = [];
        paint();
        if(cfg.cols) setCols(cfg.cols);
        if(cfg.height) setHeight(cfg.height);
        ws.nodes = restored.slice(0, MAX_NODES).map(r=>{
          const n = mkNode(r.url);
          n.vp = r.vp; n.net = r.net; n.paused = r.paused;
          return n;
        });
        paint();
        persist();
        if(cfg.cron !== undefined) setCron(cfg.cron);
        NG.diag.ok('IMPORT','Workspace restored — '+ws.nodes.length+' node(s).');
        NG.ui.toast('Workspace restored: '+ws.nodes.length+' node(s).','ok');
      }
    });
  }

  /* ============================================================
     INIT
     ============================================================ */
  function init(){
    gridEl = $('nodeGrid');
    ws = NG.workspace.load();

    gridEl.style.setProperty('--cols', ws.cols);
    setCols(ws.cols);
    setHeight(ws.height);
    $('cronSelect').value = String(ws.cron||0);
    $('btnPauseAll').textContent = ws.paused ? 'Resume All' : 'Pause All';

    paint();

    if(ws.nodes.length){
      NG.diag.ok('SESSION','Recovered '+ws.nodes.length+' node(s) from persisted workspace.');
      NG.ui.toast('Session recovered — '+ws.nodes.length+' node(s) restored.','ok');
      stamp();
    }
    if(ws.cron) setCron(ws.cron);

    return ws;
  }

  return {
    init, add, parse, paint, remove, refreshAll, pauseAll, clearAll,
    setCols, setHeight, setCron, exportWS, importWS,
    state : ()=>ws,
    MAX_NODES
  };
})();
