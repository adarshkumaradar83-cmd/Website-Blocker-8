/* ============================================================
   NEXUSGRID — PERSISTENCE
   LocalStorage: accounts, session, workspace config
   IndexedDB:    diagnostic log archive (high volume)
   ============================================================ */
const NG = window.NG = {};

NG.K = {
  ACCOUNTS : 'ng.accounts.v1',
  SESSION  : 'ng.session.v1',
  REMEMBER : 'ng.remember.v1',
  WORKSPACE: 'ng.workspace.v1',
  SEEN     : 'ng.onboard.seen.v1',
  RESETS   : 'ng.resets.v1'
};

NG.store = {
  get(k, fb){
    try{
      const raw = localStorage.getItem(k);
      return raw === null ? fb : JSON.parse(raw);
    }catch(e){ return fb; }
  },
  set(k, v){
    try{ localStorage.setItem(k, JSON.stringify(v)); return true; }
    catch(e){
      // Quota or private-mode failure must never break the UI.
      NG.diag && NG.diag.push('warn','STORE','Persistence unavailable: '+e.name);
      return false;
    }
  },
  del(k){ try{ localStorage.removeItem(k); }catch(e){} }
};

/* ---------- pseudo-hash (obfuscation only; client-side demo) ---------- */
NG.hash = function(str){
  let h1 = 0x9e3779b9, h2 = 0x85ebca6b;
  for(let i=0;i<str.length;i++){
    const c = str.charCodeAt(i);
    h1 = (h1 ^ c) * 0x01000193 >>> 0;
    h2 = (h2 + c * (i+7)) * 0x85ebca6b >>> 0;
  }
  return ('00000000'+h1.toString(16)).slice(-8) + ('00000000'+h2.toString(16)).slice(-8);
};

NG.uid = function(p){
  return (p||'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2,7);
};

/* ---------- accounts ---------- */
NG.accounts = {
  all(){ return NG.store.get(NG.K.ACCOUNTS, {}); },
  find(email){
    const a = this.all();
    return a[String(email||'').trim().toLowerCase()] || null;
  },
  create(email, pass, name){
    const key = String(email).trim().toLowerCase();
    const all = this.all();
    if(all[key]) return { ok:false, err:'Operator identity already registered on this node.' };
    all[key] = {
      email : key,
      name  : name || key.split('@')[0],
      pass  : NG.hash(pass),
      created: Date.now(),
      logins: 0
    };
    NG.store.set(NG.K.ACCOUNTS, all);
    return { ok:true, user: all[key] };
  },
  verify(email, pass){
    const u = this.find(email);
    if(!u) return { ok:false, err:'No operator record found for that identity.' };
    if(u.pass !== NG.hash(pass)) return { ok:false, err:'Credential mismatch — access denied.' };
    const all = this.all();
    all[u.email].logins = (all[u.email].logins||0) + 1;
    all[u.email].lastLogin = Date.now();
    NG.store.set(NG.K.ACCOUNTS, all);
    return { ok:true, user: all[u.email] };
  },
  setPass(email, pass){
    const all = this.all();
    const key = String(email).trim().toLowerCase();
    if(!all[key]) return false;
    all[key].pass = NG.hash(pass);
    NG.store.set(NG.K.ACCOUNTS, all);
    return true;
  }
};

/* ---------- session ---------- */
NG.session = {
  current(){ return NG.store.get(NG.K.SESSION, null); },
  open(user, remember){
    const s = {
      email: user.email,
      name : user.name,
      token: NG.uid('tok'),
      at   : Date.now(),
      remember: !!remember
    };
    NG.store.set(NG.K.SESSION, s);
    if(remember) NG.store.set(NG.K.REMEMBER, user.email);
    else NG.store.del(NG.K.REMEMBER);
    return s;
  },
  close(){ NG.store.del(NG.K.SESSION); }
};

/* ---------- workspace config ---------- */
NG.DEFAULT_WS = {
  nodes   : [],
  cols    : 3,
  height  : 300,
  cron    : 0,       // seconds; 0 = off
  paused  : false,
  drawer  : false,
  updated : 0
};

NG.workspace = {
  load(){
    const w = NG.store.get(NG.K.WORKSPACE, null);
    if(!w || typeof w !== 'object') return Object.assign({}, NG.DEFAULT_WS);
    return Object.assign({}, NG.DEFAULT_WS, w, {
      nodes: Array.isArray(w.nodes) ? w.nodes : []
    });
  },
  save(ws){
    ws.updated = Date.now();
    return NG.store.set(NG.K.WORKSPACE, ws);
  },
  clear(){ NG.store.del(NG.K.WORKSPACE); }
};

/* ============================================================
   IndexedDB — diagnostic archive
   ============================================================ */
NG.idb = (function(){
  const DB='nexusgrid', STORE='diagnostics', VER=1;
  let dbp=null, dead=false;

  function open(){
    if(dead) return Promise.reject(new Error('idb-unavailable'));
    if(dbp) return dbp;
    dbp = new Promise((res,rej)=>{
      let rq;
      try{ rq = indexedDB.open(DB,VER); }
      catch(e){ dead=true; return rej(e); }
      rq.onupgradeneeded = function(){
        const db = rq.result;
        if(!db.objectStoreNames.contains(STORE)){
          const os = db.createObjectStore(STORE,{keyPath:'id',autoIncrement:true});
          os.createIndex('ts','ts');
        }
      };
      rq.onsuccess = ()=>res(rq.result);
      rq.onerror   = ()=>{ dead=true; rej(rq.error); };
    });
    return dbp;
  }

  return {
    add(rec){
      return open().then(db=>new Promise((res,rej)=>{
        const tx = db.transaction(STORE,'readwrite');
        tx.objectStore(STORE).add(rec);
        tx.oncomplete=()=>res(true);
        tx.onerror=()=>rej(tx.error);
      })).catch(()=>false);
    },
    recent(limit){
      limit = limit||400;
      return open().then(db=>new Promise((res,rej)=>{
        const out=[];
        const tx = db.transaction(STORE,'readonly');
        const cur = tx.objectStore(STORE).index('ts').openCursor(null,'prev');
        cur.onsuccess=function(){
          const c = cur.result;
          if(c && out.length<limit){ out.push(c.value); c.continue(); }
          else res(out.reverse());
        };
        cur.onerror=()=>rej(cur.error);
      })).catch(()=>[]);
    },
    wipe(){
      return open().then(db=>new Promise((res)=>{
        const tx = db.transaction(STORE,'readwrite');
        tx.objectStore(STORE).clear();
        tx.oncomplete=()=>res(true);
        tx.onerror=()=>res(false);
      })).catch(()=>false);
    }
  };
})();
