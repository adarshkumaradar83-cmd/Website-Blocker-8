/* ============================================================
   NEXUSGRID — DIAGNOSTIC BUS
   Captures node lifecycle + system events. Never throws upward.
   ============================================================ */
NG.diag = (function(){
  const MAX = 300;
  let buf = [];
  let body = null, badge = null;
  let paintQueued = false;

  function stamp(ts){
    const d = new Date(ts);
    const p = n => ('0'+n).slice(-2);
    return p(d.getHours())+':'+p(d.getMinutes())+':'+p(d.getSeconds());
  }

  function esc(s){
    return String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  }

  function row(r){
    return '<div class="log log--'+r.lv+'">'
      + '<span class="log__t">'+stamp(r.ts)+'</span>'
      + '<span class="log__lv">'+r.lv.toUpperCase()+'</span>'
      + '<span class="log__src" title="'+esc(r.src)+'">'+esc(r.src)+'</span>'
      + '<span class="log__m">'+esc(r.msg)+'</span>'
      + '</div>';
  }

  function paint(){
    if(paintQueued) return;
    paintQueued = true;
    requestAnimationFrame(()=>{
      paintQueued = false;
      if(!body) return;
      if(!buf.length){
        body.innerHTML = '<div class="log__empty">// diagnostic channel idle — no events captured</div>';
      }else{
        body.innerHTML = buf.map(row).join('');
        body.scrollTop = body.scrollHeight;
      }
      if(badge){
        const errs = buf.filter(r=>r.lv==='err').length;
        const warns= buf.filter(r=>r.lv==='warn').length;
        badge.innerHTML = '<span class="dot '+(errs?'dot--dead':warns?'dot--warn':'dot--live')+'"></span>'
          + '<b>'+buf.length+'</b> EVENTS · <b>'+errs+'</b> ERR · <b>'+warns+'</b> WARN';
      }
    });
  }

  return {
    mount(bodyEl, badgeEl){ body = bodyEl; badge = badgeEl; paint(); },

    push(lv, src, msg){
      const rec = { lv:lv||'info', src:src||'SYSTEM', msg:String(msg), ts:Date.now() };
      buf.push(rec);
      if(buf.length > MAX) buf = buf.slice(-MAX);
      paint();
      NG.idb.add(rec);           // fire & forget; failure is swallowed
      return rec;
    },

    info(s,m){ return this.push('info',s,m); },
    ok(s,m){ return this.push('ok',s,m); },
    warn(s,m){ return this.push('warn',s,m); },
    err(s,m){ return this.push('err',s,m); },

    all(){ return buf.slice(); },

    clear(){
      buf = [];
      paint();
      NG.idb.wipe();
      this.push('info','DIAG','Diagnostic buffer and archive purged.');
    },

    /** Export the log buffer as a downloadable text report. */
    dump(){
      const lines = buf.map(r =>
        new Date(r.ts).toISOString()+'  ['+r.lv.toUpperCase().padEnd(4)+']  '+r.src.padEnd(14)+'  '+r.msg
      );
      const head = [
        'NEXUSGRID SYSTEMS — DIAGNOSTIC REPORT',
        'Generated: '+new Date().toString(),
        'Events: '+buf.length,
        '='.repeat(78), ''
      ];
      return head.concat(lines).join('\n');
    }
  };
})();

/* Global safety net: surface uncaught errors into the drawer
   instead of letting them silently break the terminal. */
window.addEventListener('error', function(e){
  if(NG.diag) NG.diag.err('RUNTIME', (e.message||'Unknown error') + ' @ ' + (e.filename||'?').split('/').pop() + ':' + (e.lineno||0));
});
window.addEventListener('unhandledrejection', function(e){
  if(NG.diag) NG.diag.err('RUNTIME','Unhandled promise rejection: ' + (e.reason && e.reason.message ? e.reason.message : e.reason));
});
