/* ============================================================
   NEXUSGRID — AUTHENTICATION
   Login / registration / recovery / support — all client-side.
   ============================================================ */
NG.SUPPORT_EMAIL = 'adarshkumar68947@gmail.com';
NG.UPI_ID        = 'Lunakumari@postbank';

NG.auth = (function(){
  const $ = id => document.getElementById(id);

  function err(field, msg){
    const el = document.querySelector('[data-err="'+field+'"]');
    if(el) el.textContent = msg || '';
    const inp = $(field);
    if(inp && inp.tagName === 'INPUT' && inp.type !== 'checkbox'){
      if(msg) inp.setAttribute('aria-invalid','true');
      else inp.removeAttribute('aria-invalid');
    }
  }

  function clearErrs(form){
    form.querySelectorAll('.field__err').forEach(e=>e.textContent='');
    form.querySelectorAll('[aria-invalid]').forEach(e=>e.removeAttribute('aria-invalid'));
  }

  const isEmail = v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v).trim());

  function strength(p){
    let s = 0;
    if(p.length >= 6) s++;
    if(p.length >= 10) s++;
    if(/[A-Z]/.test(p) && /[a-z]/.test(p)) s++;
    if(/\d/.test(p) && /[^\w\s]/.test(p)) s++;
    return Math.min(s,4);
  }

  /* ---------------- tab switching ---------------- */
  function tab(which){
    const login = which === 'login';
    $('tabLogin').setAttribute('aria-selected', login);
    $('tabReg').setAttribute('aria-selected', !login);
    $('formLogin').hidden = !login;
    $('formReg').hidden = login;
    const f = login ? $('formLogin') : $('formReg');
    clearErrs(f);
    // re-trigger entry animation
    f.style.animation='none'; void f.offsetWidth; f.style.animation='';
  }

  /* ---------------- modals ---------------- */
  function termsModal(){
    NG.ui.modal({
      title:'Terms & Conditions',
      kicker:'NexusGrid Systems · Operator Agreement v1.4',
      body:'<div class="prose">'
        +'<h4>1. Nature of Service</h4>'
        +'<p>NexusGrid Systems is a <strong>100% client-side serverless utility</strong>. All execution, rendering, and persistence occur within your browser. No account data, URL, or telemetry is transmitted to any remote server.</p>'
        +'<h4>2. Data Storage &amp; Persistence</h4>'
        +'<p>Credentials, session tokens, and workspace configuration are stored in <code>LocalStorage</code>. Diagnostic event history is archived in <code>IndexedDB</code>. Clearing browser data permanently destroys all operator records and saved workspaces. No recovery path exists outside this browser profile.</p>'
        +'<h4>3. Security Disclosure</h4>'
        +'<p>Access keys are obfuscated with a non-cryptographic digest suitable only for local demonstration. This mechanism is <strong>not</strong> a substitute for server-side authentication. Do not reuse passwords of value.</p>'
        +'<h4>4. Third-Party Content &amp; Framing</h4>'
        +'<p>Nodes render third-party content in sandboxed iframes. Many sites transmit <code>X-Frame-Options</code> or <code>Content-Security-Policy: frame-ancestors</code> headers that legitimately refuse embedding. Such refusals are logged as connection blocks and are <strong>not</strong> defects in this framework. You are responsible for ensuring you hold the right to monitor any target you dispatch.</p>'
        +'<h4>5. Network Emulation Scope</h4>'
        +'<p>Viewport and network throttling profiles are <strong>presentation-layer simulations</strong> for layout and lifecycle auditing. They shape load timing and node state within this terminal but do not alter your operating system\'s actual TCP/IP transport characteristics.</p>'
        +'<h4>6. Acceptable Use</h4>'
        +'<ul><li>No use for unauthorized surveillance or credential harvesting.</li>'
        +'<li>No automated polling at intervals that would burden a target host.</li>'
        +'<li>No circumvention of access controls on third-party systems.</li></ul>'
        +'<h4>7. Warranty</h4>'
        +'<p>Provided “as is” without warranty of any kind. The authors accept no liability for data loss, monitoring gaps, or decisions made from displayed telemetry.</p>'
        +'<h4>8. Contact</h4>'
        +'<p>Questions regarding these terms: <a href="mailto:'+NG.SUPPORT_EMAIL+'">'+NG.SUPPORT_EMAIL+'</a></p>'
        +'</div>',
      foot:'<button class="btn btn--solid" data-x>Acknowledged</button>'
    });
  }

  function supportModal(){
    NG.ui.modal({
      title:'Help & Support Center',
      kicker:'Operator assistance · Response within 48h',
      body:'<div class="prose">'
        +'<p>Direct all fault reports, feature requests, and integration questions to the support desk below. Include your browser version and any relevant lines from the <strong>Diagnostic &amp; Error Log</strong> drawer.</p>'
        +'<div class="copyrow copyrow--neon" data-copyrow style="margin:16px 0">'
        +'<span class="copyrow__k">Primary Support Email</span>'
        +'<span class="copyrow__v" data-copyval>'+NG.SUPPORT_EMAIL+'</span>'
        +'<button class="btn btn--sm" data-copybtn>Copy</button>'
        +'<a class="btn btn--sm btn--matrix" href="mailto:'+NG.SUPPORT_EMAIL+'?subject=NexusGrid%20Support%20Request">Compose</a>'
        +'</div>'
        +'<h4>Common Resolutions</h4>'
        +'<ul>'
        +'<li><strong>Node shows “Connection Refused / Frame Blocked”</strong> — the target sends anti-framing headers. This cannot be bypassed client-side; monitor a different endpoint or a site you control.</li>'
        +'<li><strong>Blank white node</strong> — the target loaded but rendered nothing above the fold. Try Desktop viewport or increase node height.</li>'
        +'<li><strong>Workspace vanished</strong> — browser data was cleared, or you are in private/incognito mode where persistence is restricted.</li>'
        +'<li><strong>Grid feels heavy past ~30 nodes</strong> — each node is a live browser context. Reduce density, raise the cron interval, or pause idle nodes.</li>'
        +'<li><strong>Forgot access key</strong> — use the client-side reset flow on the sign-in panel; it re-provisions the key locally.</li>'
        +'</ul>'
        +'<h4>Escalation</h4>'
        +'<p>For architecture-level enquiries, reference <strong>NexusGrid Core</strong> and attach an exported workspace <code>.json</code> plus a diagnostic report.</p>'
        +'</div>',
      foot:'<button class="btn btn--ghost" data-x>Close</button>'
    });
  }

  function forgotModal(){
    NG.ui.modal({
      title:'Access Key Recovery',
      kicker:'Client-side credential reset simulation',
      narrow:true,
      body:'<div class="prose" style="margin-bottom:16px">'
        +'<p>Because NexusGrid stores identities locally, recovery is performed <strong>entirely in this browser</strong> — no email is dispatched. Generate a reset token, then set a new access key.</p>'
        +'</div>'
        +'<label class="field"><span class="field__label"><span>Registered Operator ID</span></span>'
        +'<span class="field__wrap"><input class="input" type="email" id="fgEmail" placeholder="operator@nexusgrid.io"></span>'
        +'<span class="field__err" data-err="fgEmail"></span></label>'
        +'<div id="fgStage1"><button class="btn btn--solid btn--block" id="fgGen">Generate Reset Token</button></div>'
        +'<div id="fgStage2" hidden>'
        +'<div class="copyrow" data-copyrow style="margin-bottom:14px">'
        +'<span class="copyrow__k">One-Time Reset Token</span>'
        +'<span class="copyrow__v" data-copyval id="fgToken">—</span>'
        +'<button class="btn btn--sm" data-copybtn>Copy</button></div>'
        +'<label class="field"><span class="field__label"><span>Confirm Token</span></span>'
        +'<span class="field__wrap"><input class="input mono" type="text" id="fgTokenIn" placeholder="paste token"></span>'
        +'<span class="field__err" data-err="fgTokenIn"></span></label>'
        +'<label class="field"><span class="field__label"><span>New Access Key</span><span class="mono" style="color:var(--ink-4)">MIN 6</span></span>'
        +'<span class="field__wrap"><input class="input" type="password" id="fgNew" placeholder="••••••••"></span>'
        +'<span class="field__err" data-err="fgNew"></span></label>'
        +'<button class="btn btn--matrix btn--block" id="fgApply">Commit New Access Key</button>'
        +'</div>'
        +'<div class="hint" style="margin-top:16px"><span style="color:var(--amber)">▸</span>'
        +'<span>Locked out with no local record? Contact <code>'+NG.SUPPORT_EMAIL+'</code></span></div>',
      onMount(w, close){
        let token = null;
        const em = w.querySelector('#fgEmail');

        w.querySelector('#fgGen').addEventListener('click', ()=>{
          err('fgEmail','');
          const v = em.value.trim();
          if(!isEmail(v)) return err('fgEmail','Enter a valid operator email.');
          if(!NG.accounts.find(v)){
            NG.diag.warn('AUTH','Recovery attempted for unknown identity: '+v);
            return err('fgEmail','No local operator record matches that ID.');
          }
          token = ('NG-' + Math.random().toString(36).slice(2,7) + '-' + Date.now().toString(36).slice(-4)).toUpperCase();
          w.querySelector('#fgToken').textContent = token;
          w.querySelector('#fgStage1').hidden = true;
          w.querySelector('#fgStage2').hidden = false;
          const resets = NG.store.get(NG.K.RESETS, []);
          resets.push({email:v.toLowerCase(), at:Date.now()});
          NG.store.set(NG.K.RESETS, resets.slice(-20));
          NG.diag.info('AUTH','Reset token issued for '+v);
          NG.ui.toast('Reset token generated locally.','ok');
        });

        w.querySelector('#fgApply').addEventListener('click', ()=>{
          err('fgTokenIn',''); err('fgNew','');
          const t  = w.querySelector('#fgTokenIn').value.trim().toUpperCase();
          const np = w.querySelector('#fgNew').value;
          if(t !== token) return err('fgTokenIn','Token mismatch — copy the exact value above.');
          if(np.length < 6) return err('fgNew','Minimum 6 characters required.');
          if(NG.accounts.setPass(em.value.trim(), np)){
            NG.diag.ok('AUTH','Access key reset for '+em.value.trim());
            NG.ui.toast('Access key updated. Sign in with your new key.','ok');
            close();
            tab('login');
            $('liEmail').value = em.value.trim();
            $('liPass').value = '';
            $('liPass').focus();
          }else{
            err('fgNew','Reset failed — operator record unavailable.');
          }
        });
      }
    });
  }

  /* ---------------- submit handlers ---------------- */
  function doLogin(e){
    e.preventDefault();
    const f = $('formLogin');
    clearErrs(f);
    const email = $('liEmail').value.trim();
    const pass  = $('liPass').value;
    let bad = false;
    if(!isEmail(email)){ err('liEmail','Enter a valid operator email.'); bad = true; }
    if(!pass){ err('liPass','Access key required.'); bad = true; }
    if(bad) return;

    const r = NG.accounts.verify(email, pass);
    if(!r.ok){
      err('liPass', r.err);
      NG.diag.err('AUTH','Failed authentication for '+email);
      NG.ui.toast(r.err,'err');
      return;
    }
    NG.session.open(r.user, $('liRemember').checked);
    NG.diag.ok('AUTH','Operator authenticated: '+r.user.email);
    NG.app.enter(r.user, true);
  }

  function doRegister(e){
    e.preventDefault();
    const f = $('formReg');
    clearErrs(f);
    const name  = $('rgName').value.trim();
    const email = $('rgEmail').value.trim();
    const p1    = $('rgPass').value;
    const p2    = $('rgPass2').value;
    let bad = false;

    if(!isEmail(email)){ err('rgEmail','Enter a valid operator email.'); bad = true; }
    if(p1.length < 6){ err('rgPass','Minimum 6 characters required.'); bad = true; }
    if(p1 !== p2){ err('rgPass2','Access keys do not match.'); bad = true; }
    if(!$('rgTerms').checked){ err('rgTerms','You must accept the Terms & Conditions to proceed.'); bad = true; }
    if(bad) return;

    const r = NG.accounts.create(email, p1, name);
    if(!r.ok){
      err('rgEmail', r.err);
      NG.ui.toast(r.err,'err');
      return;
    }
    NG.session.open(r.user, true);
    NG.diag.ok('AUTH','Operator provisioned: '+r.user.email);
    NG.ui.toast('Operator identity provisioned.','ok');
    NG.store.del(NG.K.SEEN);          // always brief a brand-new operator
    NG.app.enter(r.user, true);
  }

  function demo(){
    const email = 'demo@nexusgrid.io', pass = 'nexusgrid';
    let u = NG.accounts.find(email);
    if(!u){
      const r = NG.accounts.create(email, pass, 'Demo Operator');
      u = r.user;
    }
    NG.accounts.verify(email, pass);
    NG.session.open(u, false);
    NG.diag.info('AUTH','Demo operator session started.');
    NG.app.enter(u, true);
  }

  /* ---------------- live telemetry feed on rail ---------------- */
  function feed(){
    const el = $('authFeed');
    if(!el) return;
    const lines = [
      'grid.scheduler ready — 100 node slots free',
      'sandbox policy applied to iframe pool',
      'localstorage adapter mounted',
      'indexeddb archive online',
      'viewport emulator profiles loaded [3]',
      'throttle profiles loaded [4G/3G/OFFLINE]',
      'diagnostic bus listening',
      'awaiting operator credentials…'
    ];
    let i = 0, out = [];
    const tick = setInterval(()=>{
      if($('authView').hidden){ clearInterval(tick); return; }
      out.push('<b>▸</b> ' + lines[i % lines.length]);
      if(out.length > 4) out.shift();
      el.innerHTML = out.join('<br>');
      i++;
    }, 1600);
  }

  /* ---------------- wiring ---------------- */
  function init(){
    document.querySelectorAll('[data-auth-tab]').forEach(b=>{
      b.addEventListener('click', ()=>tab(b.dataset.authTab));
    });

    $('formLogin').addEventListener('submit', doLogin);
    $('formReg').addEventListener('submit', doRegister);
    $('btnDemo').addEventListener('click', demo);

    document.querySelectorAll('[data-peek]').forEach(b=>{
      b.addEventListener('click', ()=>{
        const t = $(b.dataset.peek);
        const show = t.type === 'password';
        t.type = show ? 'text' : 'password';
        b.textContent = show ? 'HIDE' : 'SHOW';
      });
    });

    $('rgPass').addEventListener('input', e=>{
      $('rgMeter').dataset.lv = strength(e.target.value);
    });

    // restore remembered identity
    const remembered = NG.store.get(NG.K.REMEMBER, null);
    if(remembered){
      $('liEmail').value = remembered;
      $('liRemember').checked = true;
    }

    feed();
  }

  return { init, tab, termsModal, supportModal, forgotModal, isEmail };
})();

/* delegated modal openers (available in both views) */
document.addEventListener('click', function(e){
  const t = e.target.closest('[data-open]');
  if(!t) return;
  const which = t.dataset.open;
  if(which === 'terms')   NG.auth.termsModal();
  if(which === 'support') NG.auth.supportModal();
  if(which === 'forgot')  NG.auth.forgotModal();
});

/* delegated copy rows (UPI, support email, reset token) */
document.addEventListener('click', function(e){
  const btn = e.target.closest('[data-copybtn]');
  if(!btn) return;
  const row = btn.closest('[data-copyrow]');
  const val = row && row.querySelector('[data-copyval]');
  if(!val) return;
  NG.ui.copy(val.textContent.trim(), row, 'Value');
  btn.textContent = 'COPIED';
  setTimeout(()=>{ btn.textContent = 'Copy'; }, 1600);
});
